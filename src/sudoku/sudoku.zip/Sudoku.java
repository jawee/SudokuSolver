package sudoku;

public class Sudoku {
	public static void main(String[] args) {
		SudokuGUI gui = new SudokuGUI();
	}
}
